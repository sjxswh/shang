var State = {
	isShow:[],
	loginShow:[],
	campaignsShow:[],
	data:{},
	FooterShow:true,
	FooterHide:false
}

export default State
